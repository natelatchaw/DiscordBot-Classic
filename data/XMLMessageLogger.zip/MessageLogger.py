import os
import xml.etree.cElementTree as ET

class MessageLogger():
    def __init__(self):
        self.cwd = os.getcwd()
        self.usersFolder = ''
        self.xmlFile = ''

    async def run(self):
        self.xmlFile = '%s.%s' % (self.message.author.id, 'xml')
        self.usersFolder = os.path.abspath('./%s/users/' % self.loggingFolder)
        self.xmlPath = '%s/%s' % (self.usersFolder, self.xmlFile)

        # if the users folder does not exist
        if not os.path.isdir(self.usersFolder):
            # create the users folder
            os.mkdir(self.usersFolder)

        # if the user's xml file does not exist
        if not os.path.exists(self.xmlPath):
            # set root element
            self.root = ET.Element('user', id = str(self.message.author.id))
            # make tree from root
            self.tree = ET.ElementTree(self.root)
            # write tree to file
            self.tree.write(self.xmlPath)

        # get tree from xml file
        self.tree = ET.parse(self.xmlPath)
        # get root from tree
        self.root = self.tree.getroot()

        for word in self.message.clean_content.lower().split():
            try:
                wordEntry = self.root.find('.//%s[@name = "%s"]' % ('word', word))
                # if the word does not have an entry yet
                if wordEntry == None:
                    # create a subelement
                    wordEntry = ET.SubElement(self.root, 'word')
                    # set the name of the entry to the word
                    wordEntry.set('name', word)
                    # add a 'count' subelement to main entry
                    wordCount = ET.SubElement(wordEntry, 'count')
                    # set the count to 1
                    wordCount.text = str(1)
                # otherwise
                else:
                    # get the 'count' property for the wordEntry
                    wordCount = wordEntry.find('count')
                    # increment the 'count' property
                    wordCount.text = str(int(wordCount.text) + 1)

            except Exception as exception:
                print(exception)

        self.tree.write(self.xmlPath)

        return True
